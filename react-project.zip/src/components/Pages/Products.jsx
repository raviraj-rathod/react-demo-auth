export default function Products() {
  return (
    <div>Products</div>
  )
}
